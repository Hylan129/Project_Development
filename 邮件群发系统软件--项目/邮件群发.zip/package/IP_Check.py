#-*- coding : utf-8 -*-
import requests
from . import Time_Deal

def getcurrentip():
    burl = 'http://ip.42.pl/raw'
    try:
        internet_ip = requests.get(burl,timeout=60).text
        return internet_ip
    except Exception as e:
        print("Warning：当前网络异常，网速太差或者断网。 @" + Time_Deal.getTimeNow())
        return ''